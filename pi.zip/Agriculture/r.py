import RPi.GPIO as gpio
import sys
import time
####
import tkinter as tk


def init():
    gpio.setmode(gpio.BOARD)
    gpio.setup(7, gpio.OUT)
    gpio.setup(11, gpio.OUT)
    gpio.setup(13, gpio.OUT)
    gpio.setup(15, gpio.OUT)
    gpio.output(7, False)
    gpio.output(11, False)
    gpio.output(13, False)
    gpio.output(15, False)

def forward(tf):
    #init()
    gpio.output(13, True)
    gpio.output(15, False)
    
    gpio.output(7, False)
    gpio.output(11, True)
    time.sleep(tf)
    
def reverse(tf):
    #init()
    gpio.output(13, False)
    gpio.output(15, True)
    
    gpio.output(7, True)
    gpio.output(11, False)
    time.sleep(tf)


def pivot_left(tf):
    #init()
    gpio.output(13, True)
    gpio.output(15, False)
    gpio.output(7, True)
    gpio.output(11, False)
    time.sleep(tf)
    

def pivot_right(tf):
    #init()
    gpio.output(13, False)
    gpio.output(15, True)
    gpio.output(7, False)
    gpio.output(11, True)
    time.sleep(tf)



def turn_left(tf):
    #init()
    gpio.output(7, True)
    gpio.output(11, True)
    gpio.output(13, True)
    gpio.output(15, False)
    time.sleep(tf)


def turn_right(tf):
    #init()
    gpio.output(7, False)
    gpio.output(13, False)
    gpio.output(15, False)
    gpio.output(11, True)

    time.sleep(tf)

    
init()
forward(5)
turn_right(5)
turn_left(5)
reverse(5)
init()
